<?php
return [
    'adminEmail' => 'nithula@codeatech.com',
    'supportEmail' => 'nithula@codeatech.com',
    'user.passwordResetTokenExpire' => 3600,
];
