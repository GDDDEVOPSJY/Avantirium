<?php
return [
    'frontEndBaseUrl' => 'http://codeatechnologies.com/code/frontend/web/',            
    'frontEndHomeUrl' => 'http://www.codeatechnologies.com/code/',
    'uploadPath' => $_SERVER["DOCUMENT_ROOT"] . '/code/frontend/web/uploads/',    
    'adminEmail'=>array('nithula@codeatech.com'),
    'supportEmail'=>'nithula@codeatech.com',
    'siteName'=>'codeatechnologies.com'
];