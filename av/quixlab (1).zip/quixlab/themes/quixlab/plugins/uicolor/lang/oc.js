/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","oc",{title:"Selector de color",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Paletas de colors predefinidas",config:"Pegatz aqueste tèxte dins vòstre fichièr config.js"});